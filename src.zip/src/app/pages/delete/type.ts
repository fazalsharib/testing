/* eslint-disable eol-last */
/* eslint-disable @typescript-eslint/naming-convention */
export class pickup{
  public PickupBoyCode: string;
public PickupName: string;
public Username: string;
}
