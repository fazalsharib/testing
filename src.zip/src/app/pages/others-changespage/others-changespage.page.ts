import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-others-changespage',
  templateUrl: './others-changespage.page.html',
  styleUrls: ['./others-changespage.page.scss'],
})
export class OthersChangespagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
