/* eslint-disable max-len */
import { Component, OnInit } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-e-wallet',
  templateUrl: './e-wallet.page.html',
  styleUrls: ['./e-wallet.page.scss'],
})
export class EWalletPage implements OnInit {

  userInfo: any;
  walletData: any;

  constructor(public httpService: HttpService) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userInfo'));
    console.log(this.userInfo);
    this.httpService.get('https://www.3plindia.com/3PL/api/ThreePL/GetTransactionVendorHistory?Vendor_Code='+this.userInfo.Vendor_Code).then(resp=>{
      console.log(resp,'hiiiii');
      this.walletData = resp.data;
      console.log(this.walletData,'just');
    });

  }

}
