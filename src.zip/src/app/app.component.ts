import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'My Profile', url: 'profile', icon: 'person' },
    // { title: 'Reset M-Pin', url: '/folder/Reset M-Pin', icon: 'refresh-circle' },
    // { title: 'Settings', url: '/folder/Settings', icon: 'settings' },
    { title: 'Share 3PL', url: '/folder/Share 3pl', icon: 'share-social' },
    // { title: 'Upgrade', url: '/folder/Upgrade', icon: 'push' },
    // { title: 'Sign Out', url: '/folder/Sign Out', icon: 'log-out' },
    { title: 'Help & Support', url: 'pick-up', icon: 'help-circle' },
    { title: 'FAQ', url: '/folder/Reset M-Pin', icon: 'shield-checkmark' },
    // { title: 'Send Feedback', url: '/folder/Settings', icon: 'mail-open' },
    { title: 'About 3PL', url: '/folder/Share 3pl', icon: 'information-circle' },
  ];
  constructor(public navCtrl: NavController,
              public router: Router)
              {
                // this.initializeApp();
              }

  signOut(){
    localStorage.setItem('userInfo', '');
    this.navCtrl.navigateRoot('login');
  }
  // initializeApp(){
  //   this.router.navigateByUrl('splash');
  // }
}
