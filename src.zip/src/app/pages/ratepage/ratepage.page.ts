import { Component, OnInit } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-ratepage',
  templateUrl: './ratepage.page.html',
  styleUrls: ['./ratepage.page.scss'],
})
export class RatepagePage implements OnInit {

  modes: any;
  origins: any;
  destinations: any;

  constructor(public httpService: HttpService) { }

  ngOnInit() {
    this.modes = [];
    this.httpService.get('https://www.3plindia.com/3PL/Api/ThreePL/GetMode').then(resp=>{
      this.modes = resp.data;
    });

    this.origins = [];
    this.httpService.get('https://www.3plindia.com/3PL/Api/ThreePL/GetDestination').then(resp=>{
      this.origins = resp.data;
    });

    this.destinations = [];
    this.httpService.get('https://www.3plindia.com/3PL/Api/ThreePL/GetDestination').then(resp=>{
      this.destinations = resp.data;
    });
  }

}
